/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ManejoAlumno;

import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Hans
 */
public class MenuCajero extends javax.swing.JFrame {

    /**
     * Creates new form MenuCajero
     */
    
    Connection con;
    ResultSet rss;
    PreparedStatement pstt;
    
    
    PreparedStatement pstfact;
    ResultSet rsfact;
    public MenuCajero() {
        initComponents();
        setLocationRelativeTo(null);
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Menú cajero");

        jLabel1.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jLabel1.setText("CAJERO");

        jButton1.setText("CERRAR SESIÓN");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton5.setText("MOSTRAR DATOS");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton2.setText("PAGO ALUMNOS");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("CIERRE DE CAJA");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setText("CONSULTA DE RUBROS");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 154, Short.MAX_VALUE)
                        .addComponent(jButton1))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jButton4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addContainerGap())))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1))
                    .addComponent(jButton1))
                .addGap(18, 18, 18)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        Login lo = new Login();
        lo.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        DataAlumnosCajero da = new DataAlumnosCajero();
        da.setVisible(true);
        this.dispose();

    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        MainCajero mc = new MainCajero();
        mc.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
     //generacion de pdf de factura
            DateTimeFormatter dt = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            String fechahora =dt.format(LocalDateTime.now());//fecha_hora
            
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con= DriverManager.getConnection("jdbc:mysql://localhost/unidadedu","root","");
            // TODO add your handling code here:

            pstfact=con.prepareStatement("SELECT * FROM `factura` WHERE `fecha_hora`=?");
            pstfact.setString(1, fechahora);
            rsfact=pstfact.executeQuery();

            List<String> arr = new ArrayList<String>();

            
            while(rsfact.next()){

                arr.add("********************************\nTipo: "+rsfact.getString("tipo_recaudacion")+"\nNombre: "+rsfact.getString("nombre")+"\nCedula: "+rsfact.getString("cedula")+"\nDescripción: "+rsfact.getString("descripcion")+"\n"+" "+"\nAgencia: "+rsfact.getString("agencia")+"\nCajero: "+rsfact.getString("cajero")+"\nFecha: "+rsfact.getString("fecha_hora")+"\n"+"\nValor: "+rsfact.getString("valor")+"\nMensaje: "+rsfact.getString("mensaje")+"\n********************************\n");
                    
                /*
                System.out.println(rss.getString("id")+" "+rss.getString("firstname")+ " "+rs.sgetString("lastname")
                    +" "+rss.getString("nic")+" "+rss.getString("gender")+" "+
                    rss.getString("course")+ " "+rss.getString("batch")+" "+
                    rss.getString("telephone")+ " "+ rss.getString("address")+ " "+rss.getString("adeuda"));
                */
                //devuelve en string el tipo de usuario

                //jButton1.hide();
            
            }
            //texto formatter

            //imagen
            // Creating an ImageData object 
            Image image1 = Image.getInstance("C:\\Users\\rodri\\Desktop\\escuela\\UnidadEducativa\\src\\ManejoAlumno\\logo_e.JPG");
            image1.setAlignment(Element.ALIGN_CENTER);
            
            image1.scaleAbsolute(50, 50);
            String str = arr.toString().replaceAll("\\[|\\]", "").replaceAll(",","\n");
            int colNum = 8;
            Document document = new Document(new Rectangle(200, 800), 10, 10, 10, 10);
            String dest = System.getProperty("user.dir");
            dest += "/cierre.pdf";
            PdfWriter.getInstance(document, new FileOutputStream(dest));
            document.open();
            
            Font bold = new Font(Font.FontFamily.HELVETICA, 15, Font.BOLD);
            Font datafont = new Font(Font.FontFamily.TIMES_ROMAN, 11);
            Font bold2 = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD);
            Phrase header = new Phrase("UNIDAD EDUCATIVA FISCAL DEL MILENIO DON DARWIN", bold);
            Phrase texto = new Phrase(str,datafont);
            Phrase linea = new Phrase("***** CIERRE DE CAJA ****",bold2);
            Phrase linea2 = new Phrase("TRANSACCIONES DE: "+fechahora,bold2);
            //Phrase cabecera = new Phrase("RUC: 0998443001001\nFACT:001-111\nTipo: "+rsfact.getString("tipo_recaudacion")+"\nNombre: "+rsfact.getString("nombre")+"\nCedula: "+rsfact.getString("cedula")+"\nDescripción: "+rsfact.getString("descripcion")+"\n"+"-----------------"+"\nAgencia: "+rsfact.getString("agencia")+"\nCajero"+rsfact.getString("cajero")+"\nFecha: "+rsfact.getString("fecha_hora")+"\n-----------------"+"\nValor: "+rsfact.getString("valor")+"\nMensaje: "+rsfact.getString("mensaje")+"\n*******Gracias*******",bold2);
            
            document.add(image1);
            document.add(header);
            document.add( Chunk.NEWLINE);
            document.add( Chunk.NEWLINE);
            document.add(linea);
            document.add( Chunk.NEWLINE);
            document.add( Chunk.NEWLINE);
            document.add(linea2);
            //document.add(cabecera);
            document.add( Chunk.NEWLINE);
            document.add( Chunk.NEWLINE);
            document.add(texto);
            //document.add(table);
            
            document.close();
            JOptionPane.showMessageDialog(null, "PDF creado");
            System.out.println("PDF creado");

        } catch (SQLException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(GenPDF.class.getName()).log(Level.SEVERE, null, ex);
        } catch (DocumentException ex) {
            Logger.getLogger(GenPDF.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(MenuCajero.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        DataxAlumno da = new DataxAlumno();
        da.setVisible(true);
        this.dispose();
        
    }//GEN-LAST:event_jButton4ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MenuCajero.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MenuCajero.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MenuCajero.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MenuCajero.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MenuCajero().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
}
